xinorbis.com

maximumoctopus.com

(c) Paul Alan Freshney 2020

Requires various third party components from TMS Software and ZipMaster 1.92.

The TMS Components are commercial and cannot be distributed with the source.

All UI components from the TMS Component Pack: includes, charts, grids, ui controls, timeline, and a few others.

Use TMSLogger (though if you remove the logging code you can still compile).

ZipMaster for Delphi can be found online.



This application and code are catware. Please donate to local cat shelters or charities. Thanks.


PAF, July 22nd 2020